#include "Chess.h"

int Chess::numberBlack = 0;
int Chess::numberWhite = 0;

void Chess::drawCursor(COLORREF color)
{
	setcolor(color);
	int x = 30 * (this->x + 2);
	int y = 30 * (this->y + 2);
	line(x - 10, y - 10, x - 10 + 5, y - 10);
	line(x - 10, y - 10, x - 10, y - 10 + 5);
	line(x + 10, y - 10, x + 10 - 5, y - 10);
	line(x + 10, y - 10, x + 10, y - 10 + 5);
	line(x - 10, y + 10, x - 10 + 5, y + 10);
	line(x - 10, y + 10, x - 10, y + 10 - 5);
	line(x + 10, y + 10, x + 10 - 5, y + 10);
	line(x + 10, y + 10, x + 10, y + 10 - 5);
}

void Chess::draw()
{
	if (tag == -1)
	{
		setfillcolor(BLACK);
		setcolor(BLACK);
		fillcircle(30 * (x + 2), 30 * (y + 2), 8);

	}
	else if (tag == 1)
	{
		setfillcolor(WHITE);
		setcolor(WHITE);
		fillcircle(30 * (x + 2), 30 * (y + 2), 8);
	}
}

void Chess::draw(int x, int y, int tag)
{
	if (tag == -1)
	{
		setfillcolor(BLACK);
		setcolor(BLACK);
		fillcircle(30 * (x + 2), 30 * (y + 2), 8);

	}
	else if (tag == 1)
	{
		setfillcolor(WHITE);
		setcolor(WHITE);
		fillcircle(30 * (x + 2), 30 * (y + 2), 8);
	}
}

Chess::Chess(int position_x, int position_y, int chess_tag)
{
	x = position_x;
	y = position_y;
	tag = chess_tag;
	if (tag == -1) numberBlack++;
	else if (tag == 1)numberWhite++;
}

Chess::~Chess()
{
	if (tag == -1)
	{
		numberBlack--;
	}
	else if (tag == 1)
	{
		numberWhite--;
	}
}