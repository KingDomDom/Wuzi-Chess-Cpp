#pragma once
#include <easyx.h>
#include <graphics.h>

class Chess
{
private:
	int x;
	int y;
	int tag;//-1 is black,1 is white
	static int numberBlack;
	static int numberWhite;
public:
	Chess(int position_x, int position_y, int chess_tag);
	~Chess();

	void draw();

	void drawCursor(COLORREF color);

	static void draw(int x, int y, int tag);

	int Getx()
	{
		return x;
	}

	int Gety()
	{
		return y;
	}

	int Gettag()
	{
		return tag;
	}

	static int GetNumBlack()
	{
		return numberBlack;
	}

	static int GetNumWhite()
	{
		return numberWhite;
	}
};
