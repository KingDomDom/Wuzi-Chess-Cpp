#pragma once
#include "Button.h"
#include "Chess.h"
#include <stack>
#include <easyx.h>

class ChessBoard :
    public Button
{
private:
    int board[21][21]; //-0=null,-1=black,1=white
    stack<Chess> sta;
    int turn;
    int win;

    void judge();

public:
    void takeBack();

    void reset();

    void draw_hint();

    ChessBoard(int x, int y, void (*drawChessBoard)(int x, int y, int width, int height))
        : Button(x, y, 601, 601, drawChessBoard), turn(-1), win(0)
    {
        for (int i = 0; i < 21; i++)
        {
            for (int j = 0; j < 21; j++)
            {
                board[i][j] = 0;
            }
        }
    }

    bool click(MOUSEMSG& m);
};
