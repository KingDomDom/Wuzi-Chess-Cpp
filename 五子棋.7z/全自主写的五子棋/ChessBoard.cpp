#include "ChessBoard.h"

void ChessBoard::draw_hint()//turn stands for the next player
{
	settextstyle(30, 0, _T("Consolas"));
	outtextxy(700, 200, _T("�����ֵ�X������"));
	//black player
	settextstyle(27, 0, _T("Consolas"));
	outtextxy(700, 250, _T("�ڷ�"));
	setfillcolor(WHITE);
	setfillstyle(BS_SOLID);
	fillcircle(800, 265, 10);
	//white player
	settextstyle(27, 0, _T("Consolas"));
	outtextxy(700, 300, _T("�׷�"));
	fillcircle(800, 315, 10);
	//output hint
	if (turn == -1)//it is time for black player
	{
		setfillcolor(LIGHTRED);
		setfillstyle(BS_SOLID);
		fillcircle(800, 265, 9);
	}
	else if (turn == 1)//it is time for white player
	{
		setfillcolor(LIGHTRED);
		setfillstyle(BS_SOLID);
		fillcircle(800, 315, 9);
	}
}

void ChessBoard::reset()
{
	for (int i = 0; i < 21; i++)
		for (int j = 0; j < 21; j++)
				board[i][j] = 0;
	while (!sta.empty())
		sta.pop();

	turn = -1;
	win = 0;

	draw_hint();

	draw();
}

void ChessBoard::takeBack()
{
	if (!sta.empty())
	{
		//�ñ���������
		setcolor(RGB(255, 178, 102));
		setfillcolor(RGB(255, 178, 102));
		setfillstyle(PS_SOLID);
		fillrectangle(30 * (sta.top().Getx() + 2) - 10, 30 * (sta.top().Gety() + 2) - 10
			, 30 * (sta.top().Getx() + 2) + 10, 30 * (sta.top().Gety() + 2) + 10);

		//���ɫʮ����
		setcolor(BLACK);
		setlinestyle(PS_SOLID, 3);
		line(30 * (sta.top().Getx() + 2), max(60, 30 * (sta.top().Gety() + 2) - 11)
			, 30 * (sta.top().Getx() + 2), min(660, 30 * (sta.top().Gety() + 2) + 11));
		line(max(60, 30 * (sta.top().Getx() + 2) - 11), 30 * (sta.top().Gety() + 2)
			, min(660, 30 * (sta.top().Getx() + 2) + 11), 30 * (sta.top().Gety() + 2));

		//��ؼ���
		for (int i : {6, 11, 16})
		{
			for (int j : {6, 11, 16})
			{
				if (i == sta.top().Getx() + 1 && j == sta.top().Gety() + 1)
				{
					setfillcolor(BLACK);
					setfillstyle(BS_SOLID);
					fillcircle(30 * (i + 1), 30 * (j + 1), 4);
					fillcircle(30 * (i + 1), 30 * (j + 1), 1);
				}
			}
		}

		board[sta.top().Getx()][sta.top().Gety()] = 0;
		sta.pop();
		turn = -turn;
		if (!sta.empty()) sta.top().drawCursor(BLACK);

		win = 0;
		settextstyle(30, 0, _T("Consolas"));
		outtextxy(500, 0, _T("           "));

		draw_hint();
	}
}

void ChessBoard::judge()
{
	int i, j;
	int check[4] = { 0,0,0,0 };//0-����,1-����,2-��������,3-��������
	Chess star(sta.top());

	int x = star.Getx();
	int y = star.Gety();
	int tag = star.Gettag();

	//no one wins,out of number restiction
	if (star.GetNumBlack() + star.GetNumWhite() >= 441)
	{
		return;
	}
	else
	{
		//��ʤ����	

		//����
		for (i = 1; 0 <= x + i < 21 && 0 <= y < 21 && i <= 4; i++)
		{
			if (board[x + i][y] == tag)
				check[0]++;
			else
				break;
		}
		for (i = -1; 0 <= x + i < 21 && 0 <= y < 21 && i >= -4; i--)
		{
			if (board[x + i][y] == tag)
				check[0]++;
			else
				break;
		}
		//����
		for (j = 1; 0 <= x < 21 && 0 <= y + j < 21 && j <= 4; j++)
		{
			if (board[x][y + j] == tag)
				check[1]++;
			else
				break;
		}
		for (j = -1; 0 <= x < 21 && 0 <= y + j < 21 && j >= -4; j--)
		{
			if (board[x][y + j] == tag)
				check[1]++;
			else
				break;
		}
		//��������
		for (i = -1, j = 1; 0 <= x + i < 21 && 0 <= y + j < 21 && i >= -4 && j <= 4; i--, j++)
		{
			if (board[x + i][y + j] == tag)
				check[2]++;
			else
				break;
		}
		for (i = 1, j = -1; 0 <= x + i < 21 && 0 <= y + j < 21 && i <= 4 && j >= -4; i++, j--)
		{
			if (board[x + i][y + j] == tag)
				check[2]++;
			else
				break;
		}
		//��������
		for (i = 1, j = 1; 0 <= x + i < 21 && 0 <= y + j < 21 && i <= 4 && j <= 4; i++, j++)
		{
			if (board[x + i][y + j] == tag)
				check[3]++;
			else
				break;
		}
		for (i = -1, j = -1; 0 <= x + i < 21 && 0 <= y + j < 21 && i >= -4 && j >= -4; i--, j--)
		{
			if (board[x + i][y + j] == tag)
				check[3]++;
			else
				break;
		}
		//judge
		for (int k = 0; k < 4; k++)
		{
			if (check[k] >= 4)
			{
				settextstyle(30, 0, _T("Consolas"));
				if (tag == 1)
					outtextxy(500, 0, _T("White wins!"));
				else if (tag == -1)
					outtextxy(500, 0, _T("Black wins!"));

				win = tag; //����Ӯ��
				return;
			}
		}
		win = 0; //û��Ӯ��
	}
}

bool ChessBoard::click(MOUSEMSG& m)
{
	if (clicked(m) && win == 0)
	{
		//�ж�����Ƿ��������ڣ������Ƿ��ڽ������Χ
		if (((m.x % 30 <= 9) || (m.x % 30 >= 20)) && ((m.y % 30 <= 9) || (m.y % 30 >= 20)))
		{
			int x = int(m.x + 10) / 30 - 2;
			int y = int(m.y + 10) / 30 - 2;

			if (!board[x][y])
			{
				board[x][y] = turn;

				if (!sta.empty())
				{
					sta.top().drawCursor(RGB(255, 178, 102));
				}

				sta.push(Chess(x, y, turn));
				sta.top().draw();

				sta.top().drawCursor(BLACK);

				turn = -turn;

				judge();

				draw_hint();
				return true;
			}
		}
	}

	return false;
}