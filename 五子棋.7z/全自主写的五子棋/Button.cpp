#include "Button.h"

//��ⰴť�Ƿ񱻰���
bool Button::clicked(MOUSEMSG& m) const
{
	if (x <= m.x && m.x <= x + width - 1 && y <= m.y && m.y <= y + height - 1 && m.uMsg == WM_LBUTTONDOWN)
	{
		return true;
	}
	return false;
}

void Button::draw()
{
	drawButton(x, y, width, height);
}