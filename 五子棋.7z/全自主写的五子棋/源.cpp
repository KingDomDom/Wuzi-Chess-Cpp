// 5ziqi.cpp : ���ļ����� "main" ����������ִ�н��ڴ˴���ʼ��������
//
#include <iostream>
#include<easyx.h>
#include<graphics.h>
#include<stack>

#include "Button.h"
#include "Chess.h"
#include "ChessBoard.h"

using namespace std;

void draw_ResetButton(int x, int y, int width, int height);

void draw_TakeBackButton(int x, int y, int width, int height);

void draw_ChessBoard(int x, int y, int width, int height);


int main()
{
	MOUSEMSG m;
	int win = 0;//0���˻�ʤ��-1�ڷ���ʤ��1�׷���ʤ

	ChessBoard chessBoard(60, 60, draw_ChessBoard);
	Button takeBack(725, 500, 150, 50, draw_TakeBackButton);
	Button reset(725, 400, 150, 50, draw_ResetButton);

	initgraph(960, 720);
	setbkcolor(RGB(255, 178, 102));
	cleardevice();

	chessBoard.draw();
	takeBack.draw();
	reset.draw();

	while (1)
	{
		m = GetMouseMsg();

		chessBoard.click(m);

		//����
		if (takeBack.clicked(m))
		{
			chessBoard.takeBack();
		}
		//���¿�ʼ
		if (reset.clicked(m))
		{
			chessBoard.reset();
		}
	}


	closegraph();
	return 0;
}

void draw_ResetButton(int x, int y, int width, int height)
{
	//���¿�ʼ
	setfillstyle(BS_SOLID);
	setfillcolor(RGB(225, 128, 0));
	fillrectangle(x, y, x + width - 1, y + height - 1);
	settextcolor(LIGHTRED);
	settextstyle(30, 0, _T("Consolas"));
	outtextxy(x + 20, y + 10, _T("���¿�ʼ"));
}

void draw_TakeBackButton(int x, int y, int width, int height)
{
	//����
	setfillstyle(BS_SOLID);
	setfillcolor(RGB(202, 105, 36));
	fillrectangle(x, y, x + width - 1, y + height - 1);
	settextcolor(BROWN);
	settextstyle(30, 0, _T("Consolas"));
	outtextxy(x + 45, y + 10, _T("����"));
}

void draw_ChessBoard(int x, int y, int width, int height)
{
	setfillcolor(RGB(255, 178, 102));
	setcolor(RGB(255, 178, 102));
	fillrectangle(x - 50, y - 60, x + width - 1 + 11, y + height - 1 + 50);

	setcolor(BLACK);
	setlinestyle(PS_SOLID, 3);
	rectangle(x, y, x + width - 1, y + height - 1);//chess board from(60,60) to (660,660)

	//draw chessboard line and number
	settextcolor(BLACK);
	settextstyle(15, 0, _T("Consolas"));
	for (int i = x; i <= x + width - 1; i += 30)//every 30 steps is a point
	{
		TCHAR ci[3];
		_stprintf_s(ci, _T("%d"), (i - 60) / 30 + 1);
		outtextxy(30, i - 5, ci);
		line(60, i, 660, i);
	}

	for (int j = y; j <= y + height - 1; j += 30)//add all lines equal 21
	{
		char cj = 'A' + (j - 60) / 30;
		outtextxy(j - 5, 30, cj);
		line(j, 60, j, 660);
	}

	//draw important points,7,11,15
	for (int i : {6, 11, 16})
		for (int j : {6, 11, 16})
		{
			setfillcolor(BLACK);
			setfillstyle(BS_SOLID);
			fillcircle(30 * (i + 1), 30 * (j + 1), 4);
		}
}